﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cinema
{
    public class MoviesList
    {
        public List<Movie> data { get; set; } = new List<Movie>();
    }
}
